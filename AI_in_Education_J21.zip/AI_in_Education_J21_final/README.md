# AI in Education — Observabilité de l'agent EduMind (Jour 21)
Instrumentation d'un agent pédagogique : **logs**, **métriques**, **traces (correlation_id)**, **3 alertes**, **dashboard**.

![architecture](architecture.png)

## Démarrage
```bash
python main.py          # génère logs.jsonl, executions.csv et met à jour dashboard.html
# variante LangGraph (pip install langgraph) : python main_langgraph.py
```
Lancer **un seul** des deux scripts à la fois : ils écrivent les mêmes fichiers de sortie.
Ouvrir `dashboard.html` dans un navigateur ; `jupyter notebook notebook.ipynb` pour valider (IDs, PII, trace, 3 alertes).

## Alertes documentées
| Alerte | Seuil | Action |
|---|---|---|
| Latence | moyenne > 5 s | vérifier outil/LLM lent, réduire le contexte |
| Taux d'échec | > 20 % | consulter les logs par correlation_id, corriger l'outil fautif |
| Coût | cumul > 0,05 € (budget cumulé) | détecter boucle/prompts trop longs, plafonner les tokens |

PII (email, carte, mot de passe, téléphone) masquée avant écriture des logs.

## Résultats (40 requêtes simulées, seed 7)
Succès 85 % · latence moyenne ≈ 0,13 s · coût cumulé 0,3977 € → alerte coût déclenchée (budget de démonstration).

## Publier sur GitHub
```bash
git init && git add . && git commit -m "AI in Education: observabilité" && git branch -M main
git remote add origin https://github.com/<user>/ai-in-education-observability.git && git push -u origin main
```

## Contenu
`main.py` (agent instrumenté) · `main_langgraph.py` (même agent en graphe LangGraph) · `dashboard.html` · `notebook.ipynb` · `executions.csv` · `logs.jsonl` · `documentation.docx` · `presentation.pptx` · `flows/EdTech_kamal_2026_corrige.json` (flux Langflow Agent Radar, sans secrets : définir `OPENROUTER_API_KEY` et `MONGODB_URI`).
